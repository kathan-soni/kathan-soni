import { useState, useEffect } from "react";

const Home = (props) => {

  return <div style={{ textAlign: "center" }}>Welcome to the Canteen Portal.</div>;
};

export default Home;
